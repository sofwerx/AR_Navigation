﻿using Assets.Scripts.Managers;
using Managers;
using Mapbox.Unity.Utilities;
using Mapbox.Utils;
//using Mapbox.Utils;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace HUDElements
{
    public class AR3dItem : BaseARItem
    {
        private double m_Latitude;
        private double m_Longitude;
        private double m_Altitude = 3;
        bool contains_JsonData = false;

        public override void updateTransformInformation(Vector3 offset, float heading)
        {
            if (!aligned)
            {
                if (contains_JsonData)
                {
                    m_Latitude = (double)mJsonData["point"]["lat"];
                    m_Longitude = (double)mJsonData["point"]["lon"];

                    double altitude = 1;
                    string type = (string)mJsonData["type"];
                    if (type.Contains("Plane") || type.Contains("Helicopter"))
                    {
                        System.Random random = new System.Random();
                        altitude = random.Next(300, 900);
                    }
                }
                Vector3 unityMeters = RealWorldObjectManager.Instance.LocationManager.LatLonToUnityMeters(m_Latitude, m_Longitude);

                transform.position = new Vector3(unityMeters.x, (float)m_Altitude, unityMeters.z) + offset;
                //transform.localPosition = new Vector3(unityMeters.x, Math.Abs((float)altitude), unityMeters.z) + offset;
                m_RealWorldPosition = new GDCPoint();
                m_RealWorldPosition.Latitude = m_Latitude;
                m_RealWorldPosition.Longitude = m_Longitude;
                m_RealWorldPosition.Altitude = m_Altitude;

                aligned = true;
                 transform.RotateAround(offset, Vector3.up, heading);
            }

            UpdateElements();
        }

        public override void CreateObject(JObject jsonData, OBJECT_TYPE type, AR_TYPE arType)
        {
            try
            {
                m_ObjectType = type;
                m_ARType = arType;
                contains_JsonData = true;
                mJsonData = (JObject)jsonData["event"];
            }
            catch (Exception e)
            {
                Debug.Log(e.ToString());
            }
            enabled = true;
        }

        public override void CreateObject(double lat, double lon, OBJECT_TYPE type, AR_TYPE arType)
        {
            try
            {
                m_ObjectType = type;
                m_ARType = arType;

                m_Latitude = lat;
                m_Longitude = lon;
                enabled = true;
            }
            catch (Exception e)
            {
                Debug.Log(e.ToString());
            }
            

        }

        public override void UpdateElements()
        {
            Vector3 playerLocation = RealWorldObjectManager.Instance.LocationManager.CurrentUserLocationInUnityMeters();
            mDistanceFromPlayer = Vector3.Distance(playerLocation, transform.position);
            if (m_MapMode == LocationManager.MapMode.WorldScale)
            {
                //float scale = m_ScaleFactor/100;
                //transform.localScale = new Vector3(scale, scale, 1);

                transform.LookAt(UIController.Instance.m_firstPersonCamera.transform);
                transform.rotation = Quaternion.Euler(0.0f, transform.rotation.eulerAngles.y, transform.rotation.z);
                GetComponentInChildren<Text>().transform.LookAt(UIController.Instance.m_firstPersonCamera.transform);
                GetComponentInChildren<Text>().transform.rotation = Quaternion.LookRotation(transform.position - UIController.Instance.m_firstPersonCamera.transform.position);
            }
            GetComponentInChildren<Text>().text = mDistanceFromPlayer.ToString("0.00 m");
            //GetComponentInChildren<Text>().text = gameObject.name;
        }


    }
}