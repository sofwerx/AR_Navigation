﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets.Scripts.Managers;
using Managers;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace HUDElements
{
    class AreaOfInterest : BaseARItem
    {
        GameObject m_RouteMarkerPrefab;
        ArrayList m_RouteMarkers = new ArrayList();
        ArrayList m_RouteRealWorldPoints = new ArrayList();
        Vector3 m_CurrentOffset = Vector3.zero;
        float prevHeading = 0;

        public override void CreateObject(JObject jsonData, OBJECT_TYPE type, AR_TYPE arType)
        {
            throw new NotImplementedException();
        }

        public override void CreateObject(double lat, double lon, OBJECT_TYPE type, AR_TYPE arType)
        {
            throw new NotImplementedException();
        }

        public void CreateObject(ArrayList points, OBJECT_TYPE type, AR_TYPE arType)
        {
            try
            {
                m_ObjectType = type;
                m_ARType = arType;

                transform.rotation = Quaternion.Euler(0, 0, 0);
                //Parse out the markers one at a time                
                Bounds bounds = new Bounds();
                foreach (KeyValuePair<double, double> point in points)
                {
                    double lat = point.Key;
                    double lon = point.Value;

                    transform.position = RealWorldObjectManager.Instance.LocationManager.LatLonToUnityMeters(lat, lon);
                    GameObject obj = (GameObject)Instantiate(Resources.Load("3D_AR_WAYPOINT"));
                    obj.transform.parent = transform;

                    Vector3 pos = RealWorldObjectManager.Instance.LocationManager.LatLonToUnityMeters(lat, lon);
                    obj.transform.position = new Vector3(pos.x, -5f, pos.y);

                    bounds.Encapsulate(pos);

                    GDCPoint wayPointPosition = new GDCPoint();
                    wayPointPosition.Latitude = lat;
                    wayPointPosition.Longitude = lon;
                    wayPointPosition.Altitude = -2;

                    m_RouteMarkers.Add(obj);
                    m_RouteRealWorldPoints.Add(wayPointPosition);
                }
                transform.position = bounds.center;
            }
            catch (Exception e)
            {
                Debug.Log(e.ToString());
            }

        }


        public override void UpdateElements()
        {
        }

        public override void updateTransformInformation(Vector3 offset, float heading)
        {
            if (!aligned)
            {
                for (int i = 0; i < m_RouteMarkers.Count; ++i)
                {
                    GameObject routeObj = (GameObject)m_RouteMarkers[i];
                    GDCPoint routePoint = (GDCPoint)m_RouteRealWorldPoints[i];

                    Vector3 objPosition = routeObj.transform.position + offset;
                    if (!aligned)
                    {
                        double lat = routePoint.Latitude;
                        double lon = routePoint.Longitude;
                        objPosition = RealWorldObjectManager.Instance.LocationManager.LatLonToUnityMeters(lat, lon);
                        routeObj.transform.position = new Vector3(objPosition.x, 0f, objPosition.z);
                    }
                    if (prevHeading != heading)
                    {
                        routeObj.transform.RotateAround(offset, Vector3.up, heading);
                    }
                }
            }

            for (int i = 0; i < m_RouteMarkers.Count; ++i)
            {
                if (i + 1 < m_RouteMarkers.Count)
                {
                    GameObject point1 = (GameObject)m_RouteMarkers[i];
                    GameObject point2 = (GameObject)m_RouteMarkers[i + 1];

                    if (m_MapMode == LocationManager.MapMode.TableScale)
                    {
                        point1.transform.position = new Vector3(point1.transform.position.x, 1.1f, point1.transform.position.z);
                        point2.transform.position = new Vector3(point2.transform.position.x, 1.1f, point2.transform.position.z);
                    }
                    else
                    {
                        point1.transform.position = new Vector3(point1.transform.position.x, -10.01f, point1.transform.position.z);
                        point2.transform.position = new Vector3(point2.transform.position.x, -10.01f, point2.transform.position.z);
                    }

                    point1.GetComponent<LineRenderer>().SetPosition(0, point1.transform.position);
                    point1.GetComponent<LineRenderer>().SetPosition(1, point2.transform.position);


                }
            }

            m_CurrentOffset = offset;
            prevHeading = heading;
            aligned = true;

        }
    }
}
