using Managers;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace HUDElements
{
    public abstract class BaseARItem : MonoBehaviour
    {
        public struct GDCPoint
        {
            public double Latitude, Longitude, Altitude, x_meters, y_meters, z_meters;
        }

        public struct ImageInfo
        {
            public string imageName;
            public Color32 m_Color;
        }

        public enum OBJECT_TYPE
        {
            TEAM_MEMBER,
            OBJECT,
            ROUTE
        };

        public enum AR_TYPE
        {
            COTS,
            MEDIC
        };

        protected JObject mJsonData;

        protected double mDistanceFromPlayer;

        protected const int EarthRadius = 6378137; //no seams with globe example
        protected const double OriginShift = 2 * Math.PI * EarthRadius / 2;

        protected GDCPoint m_RealWorldPosition;
        protected bool m_IsRealWorldSpace = true;
        protected bool m_PositionDirty = false;

        protected OBJECT_TYPE m_ObjectType;
        protected AR_TYPE m_ARType;
        public LocationManager.MapMode m_MapMode;
        protected float m_ScaleFactor;

        public bool aligned = false;

        protected Dictionary<string, ImageInfo> mCOTSImageMap = new Dictionary<string, ImageInfo>()
        {
            { "a-h-G-E-V", new ImageInfo {imageName="HostileHRed_Units", m_Color = new Color32(255, 129, 130, 255) } },
            { "a-h-G-E-X-M", new ImageInfo {imageName="HostileHRed_Subsurface_U", m_Color = new Color32(255, 129, 130, 255) } },
            { "a-h-G-I", new ImageInfo {imageName="HostileHRed_Installations", m_Color = new Color32(255, 129, 130, 255) } },
            { "a-h-S", new ImageInfo {imageName="HostileHRed_SeaSurface_S", m_Color = new Color32(255, 129, 130, 255) } },
            { "a-h-G", new ImageInfo {imageName="HostileHRed_Units", m_Color = new Color32(255, 129, 130, 255) } },
            { "a-h-G-U-C-I-d", new ImageInfo {imageName="HostileHRed_Units", m_Color = new Color32(255, 129, 130, 255) } },
            { "a-h-G-E-V-A-T", new ImageInfo {imageName="HostileHRed_Equipment", m_Color = new Color32(255, 129, 130, 255) } },
            { "a-h-G-U-C-F", new ImageInfo {imageName="HostileHRed_Equipment", m_Color = new Color32(255, 129, 130, 255) } },
            { "a-h-G-U-C-I", new ImageInfo {imageName="HostileHRed_Units", m_Color = new Color32(255, 129, 130, 255) } },
            { "a-h-A", new ImageInfo {imageName="HostileHRed_Air_A", m_Color = new Color32(255, 129, 130, 255) } },

            { "a-f-G-U-C-I", new ImageInfo {imageName="FriendFCyan_Units", m_Color = new Color32(128, 223, 255, 255) } },
            { "a-f-G-E-X-M", new ImageInfo {imageName="FriendFCyan_Subsurface_U", m_Color = new Color32(128, 223, 255, 255) } },
            { "a-f-G-I", new ImageInfo {imageName="FriendFCyan_Installations", m_Color = new Color32(128, 223, 255, 255) } },
            { "a-f-G-U-C-I-d", new ImageInfo {imageName="FriendFCyan_Units", m_Color = new Color32(128, 223, 255, 255) } },
            { "a-f-A", new ImageInfo {imageName="FriendFCyan_Air_A", m_Color = new Color32(128, 223, 255, 255) } },
            { "a-f-G-E-V-A-T", new ImageInfo {imageName="FriendFCyan_Units", m_Color = new Color32(128, 223, 255, 255) } },
            { "a-f-S", new ImageInfo {imageName="FriendFCyan_SeaSurface_S", m_Color = new Color32(128, 223, 255, 255) } },
            { "a-f-G-U-C-F", new ImageInfo {imageName="FriendFCyan_Units", m_Color = new Color32(128, 223, 255, 255) } },
            { "a-f-G-E-V", new ImageInfo {imageName="FriendFCyan_Equipment", m_Color = new Color32(128, 223, 255, 255) } },
            { "a-f-G", new ImageInfo {imageName="FriendFCyan_Units", m_Color = new Color32(128, 223, 255, 255) } },

            { "a-n-G-E-V-A-T", new ImageInfo {imageName="NeutralNGreen_Subsurface_U", m_Color = new Color32(170, 255, 170, 255) } },
            { "a-n-G-U-C-I", new ImageInfo {imageName="NeutralNGreen_Units", m_Color = new Color32(170, 255, 170, 255) } },
            { "a-n-G-U-C-I-d", new ImageInfo {imageName="NeutralNGreen_Units", m_Color = new Color32(170, 255, 170, 255) } },
            { "a-n-G-E-V", new ImageInfo {imageName="NeutralNGreen_Units", m_Color = new Color32(170, 255, 170, 255) } },
            { "a-n-G", new ImageInfo {imageName="NeutralNGreen_Units", m_Color = new Color32(170, 255, 170, 255) } },
            { "a-n-A", new ImageInfo {imageName="NeutralNGreen_Air_A", m_Color = new Color32(170, 255, 170, 255) } },
            { "a-n-G-U-C-F", new ImageInfo {imageName="NeutralNGreen_Equipment", m_Color = new Color32(170, 255, 170, 255) } },
            { "a-n-G-E-X-M", new ImageInfo {imageName="NeutralNGreen_Subsurface_U", m_Color = new Color32(170, 255, 170, 255) } },
            { "a-n-G-I", new ImageInfo {imageName="NeutralNGreen_Installations", m_Color = new Color32(170, 255, 170, 255) } },
            { "a-n-S", new ImageInfo {imageName="NeutralNGreen_SeaSurface_S", m_Color = new Color32(170, 255, 170, 255) } },

            { "a-u-G-E-V-A-T", new ImageInfo {imageName="UnknownUYellow_Equipment", m_Color = new Color32(255, 253, 135, 255) } },
            { "a-u-G-U-C-I", new ImageInfo {imageName="UnknownUYellow_Units", m_Color = new Color32(255, 253, 135, 255) } },
            { "a-u-G-U-C-I-d", new ImageInfo {imageName="UnknownUYellow_Units", m_Color = new Color32(255, 253, 135, 255) } },
            { "a-u-G-E-V", new ImageInfo {imageName="UnknownUYellow_Units", m_Color = new Color32(255, 253, 135, 255) } },
            { "a-u-G", new ImageInfo {imageName="UnknownUYellow_Units", m_Color = new Color32(255, 253, 135, 255) } },
            { "a-u-A", new ImageInfo {imageName="UnknownUYellow_Air_A", m_Color = new Color32(255, 253, 135, 255) } },
            { "a-u-G-U-C-F", new ImageInfo {imageName="UnknownUYellow_Equipment", m_Color = new Color32(255, 253, 135, 255) } },
            { "a-u-G-E-X-M", new ImageInfo {imageName="UnknownUYellow_Subsurface_U", m_Color = new Color32(255, 253, 135, 255) } },
            { "a-u-G-I", new ImageInfo {imageName="UnknownUYellow_Installations", m_Color = new Color32(255, 253, 135, 255) } },
            { "a-u-S", new ImageInfo {imageName="UnknownUYellow_SeaSurface_S", m_Color = new Color32(255, 253, 135, 255) } },


            { "burger", new ImageInfo {imageName="burger", m_Color = new Color32(0, 168, 220, 255) } },
            { "Plane", new ImageInfo {imageName="Plane", m_Color = new Color32(0, 168, 220, 255) } },
            { "Helicopter", new ImageInfo {imageName="Helicopter", m_Color = new Color32(0, 168, 220, 255) } },
            { "Medical", new ImageInfo {imageName="TALOS_ARD_Medic_Icon", m_Color = new Color32(0, 168, 220, 255) } }
        };

        public JObject JSONData
        {
            get { return mJsonData; }
            set { mJsonData = value; }
        }

        public float ScaleFactor
        {
            get { return m_ScaleFactor; }
            set { m_ScaleFactor = value; }
        }

        public OBJECT_TYPE ObjectType
        {
            get { return m_ObjectType; }
        }

        public LocationManager.MapMode MapMode
        {
            get { return m_MapMode; }
            set { m_MapMode = value; }
        }

        public ImageInfo ImageInfoData
        {
            get
            {
                string type = (string)mJsonData["type"];
                return mCOTSImageMap[type];
            }
        }
        public GDCPoint RealWorldPosition
        {
            get { return m_RealWorldPosition; }
        }

        public AR_TYPE ARType
        {
            get { return m_ARType; }
        }

        public double DistanceFromPlayer
        {
            get { return mDistanceFromPlayer; }
        }

        abstract public void UpdateElements();
        abstract public void CreateObject(JObject jsonData, OBJECT_TYPE type, AR_TYPE arType);
        abstract public void CreateObject(double lat, double lon, OBJECT_TYPE type, AR_TYPE arType);
        abstract public void updateTransformInformation(Vector3 offset, float heading);

        private void Update()
        {
            UpdateElements();
        }
    }
}