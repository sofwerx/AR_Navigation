﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Utils
{
    namespace NativeHelpers
    {
        namespace Android
        {
            public class AndroidHelper
            {
                public static string GetAndroidContextExternalFilesDir()
                {
                    string path = "";

                    if (Application.platform == RuntimePlatform.Android)
                    {
                        try
                        {
                            using (AndroidJavaClass ajc = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                            {
                                using (AndroidJavaObject ajo = ajc.GetStatic<AndroidJavaObject>("currentActivity"))
                                {
                                    path = ajo.Call<AndroidJavaObject>("getExternalFilesDir", null).Call<string>("getAbsolutePath");
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            Debug.LogWarning("Error fetching native Android external storage dir: " + e.Message);
                        }
                    }
                    return path;
                }

                public static string GetEnvironmentExternal()
                {
                    string path = null;

                    if (Application.platform == RuntimePlatform.Android)
                    {
                        try
                        {
                            using (AndroidJavaClass ajc = new AndroidJavaClass("android.os.Environment"))
                            {
                                path = ajc.CallStatic<AndroidJavaObject>("getExternalStorageDirectory", null).Call<string>("getAbsolutePath");
                            }
                        }
                        catch (Exception e)
                        {
                            Debug.LogWarning("Error fetching native Android external storage dir: " + e.Message);
                        }
                    }
                    return path;
                }

                public static string GetSystemExternal()
                {
                    string path = null;

                    if (Application.platform == RuntimePlatform.Android)
                    {
                        try
                        {
                            using (AndroidJavaClass ajc = new AndroidJavaClass("android.system.Os"))
                            {
                                path = ajc.CallStatic<string>("getenv", "EXTERNAL_STORAGE");
                            }
                        }
                        catch (Exception e)
                        {
                            Debug.LogWarning("Error fetching native Android external storage dir: " + e.Message);
                        }
                    }
                    return path;
                }

                public static string GetSystemExternalSecondary()
                {
                    string path = null;

                    if (Application.platform == RuntimePlatform.Android)
                    {
                        try
                        {
                            using (AndroidJavaClass ajc = new AndroidJavaClass("android.system.Os"))
                            {
                                path = ajc.CallStatic<string>("getenv", "SECONDARY_STORAGE");
                            }
                        }
                        catch (Exception e)
                        {
                            Debug.LogWarning("Error fetching native Android external storage dir: " + e.Message);
                        }
                    }
                    return path;
                }

                public static string[] GetAndroidContextExternalFilesDirs()
                {
                    string[] paths = null;

                    if (Application.platform == RuntimePlatform.Android)
                    {
                        try
                        {
                            using (AndroidJavaClass ajc = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                            {
                                using (AndroidJavaObject ajo = ajc.GetStatic<AndroidJavaObject>("currentActivity"))
                                {
                                    AndroidJavaObject[] fileObjects = ajo.Call<AndroidJavaObject[]>("getExternalFilesDirs", null);
                                    paths = new string[fileObjects.Length];
                                    for (int i = 0; i < fileObjects.Length; i++)
                                    {
                                        paths[i] = fileObjects[i].Call<string>("getAbsolutePath");
                                    }
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            Debug.LogWarning("Error fetching native Android external storage dir: " + e.Message);
                        }
                    }
                    return paths;
                }

                public static string GetAndroidContextInternalFilesDir()
                {
                    string path = "";

                    if (Application.platform == RuntimePlatform.Android)
                    {
                        try
                        {
                            using (AndroidJavaClass ajc = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                            {
                                using (AndroidJavaObject ajo = ajc.GetStatic<AndroidJavaObject>("currentActivity"))
                                {
                                    path = ajo.Call<AndroidJavaObject>("getFilesDir").Call<string>("getAbsolutePath");
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            Debug.LogWarning("Error fetching native Android internal storage dir: " + e.Message);
                        }
                    }
                    return path;
                }

                public static AndroidJavaObject getNativeInterface()
                {
                    AndroidJavaObject instance = null;
                    AndroidJavaObject activityContext = null;

                    using (AndroidJavaClass activityClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                    {
                        activityContext = activityClass.GetStatic<AndroidJavaObject>("currentActivity");
                    }
                    using (AndroidJavaClass pluginClass = new AndroidJavaClass("designinteractive.com.arnavigationplugin.UnityInterface"))
                    {
                        if (pluginClass != null)
                        {
                            instance = pluginClass.CallStatic<AndroidJavaObject>("getInstance");
                        }
                    }

                    return instance;
                }
            }
        }
    }
}
