﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using System.Linq;
using Utils.NativeHelpers.Android;

namespace Utils
{
    namespace File
    {
        public class TalosFileFinder
        {
            private TalosFileFinder() { }

            private static string configFilePath = "";
            private static string menuFilePath = "";
            private static string operatingDirectory = "";

            public static string GetOperatingDirectory()
            {
                if (TalosFileFinder.operatingDirectory.Length > 0)
                {
                    return TalosFileFinder.operatingDirectory;
                }
                List<string> potentialDirectories = TalosFileFinder.GetAllPotentialDirectories();
                foreach (string potentialDirectory in potentialDirectories)
                {
                    Debug.Log("Looking for config files in: " + potentialDirectory);
                    string[] files = Directory.GetFiles(potentialDirectory, "*.xml", SearchOption.TopDirectoryOnly);
                    IEnumerable<string> talosConfigFiles = files.Where(f => f.ToLower().Contains("talos")).Where(f => f.ToLower().Contains("config"));
                    if (talosConfigFiles.Count() > 0)
                    {
                        Debug.Log("Config file found in above directory");
                        TalosFileFinder.operatingDirectory = potentialDirectory;
                        return TalosFileFinder.operatingDirectory;
                    }
                }
                return "";
            }

            public static string GetConfigFilePath()
            {
                if (TalosFileFinder.configFilePath.Length > 0)
                {
                    return TalosFileFinder.configFilePath;
                }
                string directory = TalosFileFinder.GetOperatingDirectory();
                string[] files = Directory.GetFiles(directory, "*.xml", SearchOption.TopDirectoryOnly);
                IEnumerable<string> talosConfigFiles = files.Where(f => f.ToLower().Contains("talos")).Where(f => f.ToLower().Contains("config"));
                if (talosConfigFiles.Count() > 0)
                {
                    Debug.Log("Config file found in above directory");
                    TalosFileFinder.configFilePath = talosConfigFiles.FirstOrDefault(); ;
                }

                if (TalosFileFinder.configFilePath.Length <= 0)
                    throw new FileNotFoundException("Could not find any talos config file in directory");

                return TalosFileFinder.configFilePath;
            }

            public static string GetMenuFilePath()
            {
                if (TalosFileFinder.menuFilePath.Length > 0)
                {
                    return TalosFileFinder.menuFilePath;
                }
                string directory = TalosFileFinder.GetOperatingDirectory();
                string[] files = Directory.GetFiles(directory, "*.xml", SearchOption.TopDirectoryOnly);
                IEnumerable<string> talosMenuFiles = files.Where(f => f.ToLower().Contains("talos")).Where(f => f.ToLower().Contains("menu"));
                if (talosMenuFiles.Count() > 0)
                {
                    Debug.Log("Config file found in above directory");
                    TalosFileFinder.menuFilePath = talosMenuFiles.FirstOrDefault(); ;
                }

                if (talosMenuFiles.Count() <= 0)
                    throw new FileNotFoundException("Could not find any talos config file in directory");

                return TalosFileFinder.menuFilePath;
            }

            public static List<string> GetAllPotentialDirectories()
            {
                List<string> potentialDirectories = new List<string>();
#if UNITY_ANDROID && !UNITY_EDITOR
                string[] paths = AndroidHelper.GetAndroidContextExternalFilesDirs();
                potentialDirectories.AddRange(paths.Select(p => p + "/"));
                potentialDirectories.Add(Application.persistentDataPath);
#else
                potentialDirectories.Add(Application.dataPath);
                potentialDirectories.Add(Application.persistentDataPath);
#endif
                return potentialDirectories;
            }

            public static string GetDirectoryPath(string directoryName)
            {
                string directoryPath = null;
                List<string> directories = GetAllPotentialDirectories();
                foreach (string directory in directories)
                {
                    string[] subDirectories = Directory.GetDirectories(directory);
                    for (int i = 0; i < subDirectories.Length; ++i)
                    {
                        string sub = subDirectories[i];
                        if (sub.Contains(directoryName))
                        {
                            directoryPath = subDirectories[i];
                            break;
                        }
                    }
                }

                return directoryPath;
            }

            private static void printallfiles(string directory)
            {
                Debug.Log("All files in " + directory);
                string[] allFiles = Directory.GetFiles(directory);
                if (allFiles.Length == 0) Debug.Log("no files found");
                foreach (string file in allFiles)
                {
                    Debug.Log(file);
                }
            }
        }
    }
}
