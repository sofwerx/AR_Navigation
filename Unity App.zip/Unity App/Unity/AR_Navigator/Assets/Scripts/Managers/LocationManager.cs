﻿using System;
using System.Collections;
using System.Collections.Generic;
using Mapbox.Unity.Ar;
using UnityEngine;
using UnityEngine.UI;
using HUDElements;
using Mapbox.Unity.Map;

namespace Managers
{
    public abstract class LocationManager : Singleton<LocationManager>
    {
        public event Action OnLocationUpdated;

        [SerializeField]
        protected float m_TableTopScale;

        [SerializeField]
        protected float m_RealWorldScale;

        public enum MapMode
        {
            WorldScale,
            TableScale
        }

        protected bool m_TableTopMode = false;

        public abstract float CompassHeading
        {
            get;
        }

        public abstract Vector3 CurrentOffset
        {
            get;
        }

        public abstract float CurrentRotationOffset
        {
            get ;
        }

        public MapMode m_CurrentMode;

        public abstract Vector3 CurrentUserLocation();
        public abstract Vector3 LatLonToUnityMeters(double lat, double lon);
        public abstract Vector3 CurrentUserLocationInUnityMeters();
        public abstract void OnAlignmentAvailable(Vector3 point, float rotation);

        public abstract double GetPlayerHeight();
        public abstract double GetHeightAtPoint(double lat, double lon);
        public abstract void AddARItemToMap(BaseARItem item);

        public abstract void SplatMap();

        public abstract float GetWorldScale();
        public abstract float GetTableScale();

        public abstract void SwitchMode();

        protected abstract void Initialize();
        // Use this for initialization
        IEnumerator Start()
        {
            Initialize();

#if UNITY_EDITOR || UNITY_WSA
            yield return null;
#else
            Input.location.Start(5);

            // Wait until service initializes
            int maxWait = 20;
            while (Input.location.status == LocationServiceStatus.Initializing && maxWait > 0)
            {
                yield return new WaitForSeconds(1);
                maxWait--;
            }

            // Service didn't initialize in 20 seconds
            if (maxWait < 1)
            {
                print("Timed out");
                yield break;
            }

            // Connection has failed
            if (Input.location.status == LocationServiceStatus.Failed)
            {
                print("Unable to determine device location");
                yield break;
            }
            else
            {
                
                // Access granted and location value could be retrieved                
                print("Location: " + Input.location.lastData.latitude.ToString("R") + " " + Input.location.lastData.longitude.ToString("R") + " " + Input.location.lastData.altitude.ToString("R") + " " + Input.location.lastData.horizontalAccuracy + " " + Input.location.lastData.timestamp);
                Input.compass.enabled = true;
            }
#endif
        }
    }
}