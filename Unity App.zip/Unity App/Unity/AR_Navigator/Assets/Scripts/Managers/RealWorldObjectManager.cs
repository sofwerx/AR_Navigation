﻿using HUDElements;
using Managers;
using Mapbox.Unity.Ar;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.Managers
{
    public class RealWorldObjectManager : Singleton<RealWorldObjectManager>
    {
        [SerializeField]
        GameObject m_HUD1;

        [SerializeField]
        GameObject m_HUD2;

        [SerializeField]
        GameObject m_HUD3;

        [SerializeField]
        GameObject m_HUD4;

        [SerializeField]
        LocationManager m_LocationManager;

        [SerializeField]
        GameObject POI_PREFAB;

        [SerializeField]
        GameObject CNP_PREFAB;

        [SerializeField]
        GameObject AOI_PREFAB;

        Dictionary<string, GameObject> mRealWorldObjects = new Dictionary<string, GameObject>();

        public LocationManager LocationManager
        {
            get { return m_LocationManager; }
        }

        public Dictionary<string, GameObject> RealWorldObjects
        {
            get { return mRealWorldObjects; }
        }

        void Start()
        {
        }

        public void clearPoints()
        {
            foreach (KeyValuePair<string, GameObject> obj in mRealWorldObjects)
            {
                Destroy(obj.Value);
            }
            mRealWorldObjects.Clear();
        }

        public void reloadPoints()
        {
            foreach (KeyValuePair<string, GameObject> arObject in mRealWorldObjects)
            {
                if (arObject.Value.GetComponent<BaseARItem>() != null)
                {
                    arObject.Value.GetComponent<BaseARItem>().aligned = false;
                }
            }
        }

        public void updateAlignment(Vector3 point, float heading)
        {
            foreach (KeyValuePair<string, GameObject> arObject in mRealWorldObjects)
            {
                if (arObject.Value.GetComponent<BaseARItem>() != null)
                {
                    arObject.Value.GetComponent<BaseARItem>().updateTransformInformation(point, heading);
                }
            }

        }

        public void setAREnabled(bool status, AR3dItem.AR_TYPE type)
        {
            foreach (KeyValuePair<string, GameObject> arObject in mRealWorldObjects)
            {
                if (arObject.Value.GetComponent<BaseARItem>().ARType == type)
                {
                    arObject.Value.SetActive(status);
                }
            }
        }

        public void setObjectEnabled(string uid, bool status)
        {
            if (mRealWorldObjects.ContainsKey(uid))
            {
                mRealWorldObjects[uid].SetActive(status);
            }
            else
            {
                Debug.Log("RealWorldObjectManager::setObjectEnabled does not contain key: " + uid);
            }
        }

        public void updateScaleFactor(float scaleFactor)
        {
            foreach (KeyValuePair<string, GameObject> arObject in mRealWorldObjects)
            {
                arObject.Value.GetComponent<BaseARItem>().ScaleFactor = scaleFactor;
            }
        }

        public void switchMode(LocationManager.MapMode mapMode)
        {
            foreach (KeyValuePair<string, GameObject> arObject in mRealWorldObjects)
            {
                if(arObject.Value.GetComponent<BaseARItem>().ObjectType == BaseARItem.OBJECT_TYPE.OBJECT)
                {
                    if (mapMode == LocationManager.MapMode.TableScale)
                    {
                        arObject.Value.transform.localRotation = Quaternion.Euler(new Vector3(90, 0, 0));
                    }
                    else
                    {
                        arObject.Value.transform.localRotation = Quaternion.Euler(new Vector3(0, 0, 0));
                    }
                }
                arObject.Value.GetComponent<BaseARItem>().MapMode = mapMode;
                //arObject.Value.GetComponent<BaseARItem>().aligned = false;
                arObject.Value.GetComponent<BaseARItem>().updateTransformInformation(
                            m_LocationManager.CurrentOffset, m_LocationManager.CurrentRotationOffset);
                
            }
        }

        public void geopackageParser(JArray geoPackageData)
        {
            foreach(JObject feature in geoPackageData)
            {
                string featureName = (string)feature["FeatureName"];
                JArray featureInfo = (JArray)feature["FeatureInfo"];

                if (featureName.Contains("route_") || featureName.Contains("aoi_"))
                {
                    foreach (JObject featurePoint in featureInfo)
                    {
                        ArrayList points = new ArrayList();
                        JArray jPoints;
                        if (featureName.Contains("route_"))
                        {
                            jPoints = (JArray)featurePoint["geom"]["MULTILINESTRING"][0];
                        }
                        else
                        {
                            jPoints = (JArray)featurePoint["geom"]["MULTIPOLYGON"][0][0];
                        }
                        foreach (JObject routePoints in jPoints)
                        {
                            double lon = (double)routePoints["x"];
                            double lat = (double)routePoints["y"];
                            points.Add(new KeyValuePair<double, double>(lat, lon));
                        }
                        string name = featureName + ": " + featurePoint["id"] + "_" + featurePoint["fid"];

                        if (featureName.Contains("route_"))
                        {
                            Route route = new GameObject().AddComponent<Route>();
                            route.ScaleFactor = m_LocationManager.GetWorldScale();
                            route.MapMode = m_LocationManager.m_CurrentMode;
                            m_LocationManager.AddARItemToMap(route);

                            route.CreateObject(points, BaseARItem.OBJECT_TYPE.ROUTE, BaseARItem.AR_TYPE.COTS);

                            route.name = name;
                            route.updateTransformInformation(m_LocationManager.CurrentOffset, m_LocationManager.CurrentRotationOffset);
                            mRealWorldObjects.Add(name, route.gameObject);
                        }
                        else
                        {
                            GameObject obj = (GameObject)Instantiate(AOI_PREFAB);
                            AreaOfInterest aoi = obj.GetComponent<AreaOfInterest>();
                            aoi.ScaleFactor = m_LocationManager.GetWorldScale();
                            aoi.MapMode = m_LocationManager.m_CurrentMode;
                            m_LocationManager.AddARItemToMap(aoi);

                            aoi.CreateObject(points, BaseARItem.OBJECT_TYPE.ROUTE, BaseARItem.AR_TYPE.COTS);

                            aoi.name = name;
                            aoi.updateTransformInformation(m_LocationManager.CurrentOffset, m_LocationManager.CurrentRotationOffset);
                            mRealWorldObjects.Add(name, obj.gameObject);

                        }
                    }
                }
                else if (featureName.Contains("poi_") || featureName.Contains("cnp_"))
                {
                    foreach (JObject featurePoint in featureInfo)
                    {
                        double lon = (double)featurePoint["geom"]["MULTIPOINT"][0]["x"];
                        double lat = (double)featurePoint["geom"]["MULTIPOINT"][0]["y"];

                        GameObject obj;
                        if (featureName.Contains("poi_"))
                        {
                            obj = (GameObject)Instantiate(POI_PREFAB);
                        }
                        else
                        {
                            obj = (GameObject)Instantiate(CNP_PREFAB);
                        }


                        m_LocationManager.AddARItemToMap(obj.GetComponent<AR3dItem>());
                        string name = featureName + ": " + featurePoint["id"] + "_" + featurePoint["fid"];
                        BaseARItem.OBJECT_TYPE type = AR3dItem.OBJECT_TYPE.OBJECT;
                        BaseARItem.AR_TYPE arType = BaseARItem.AR_TYPE.COTS;

                        obj.GetComponent<AR3dItem>().CreateObject(lat, lon, type, arType);
                        obj.GetComponent<AR3dItem>().ScaleFactor = m_LocationManager.GetWorldScale();
                        obj.GetComponent<AR3dItem>().MapMode = m_LocationManager.m_CurrentMode;

                        if (m_LocationManager.m_CurrentMode == LocationManager.MapMode.TableScale)
                        {
                            obj.transform.localRotation = Quaternion.Euler(new Vector3(90, 0, 0));
                        }

                        obj.GetComponent<AR3dItem>().updateTransformInformation(
                            m_LocationManager.CurrentOffset, m_LocationManager.CurrentRotationOffset);

                        obj.name = name;
                        obj.tag = "RealWorldObject";

                        // Store it for updates later
                        mRealWorldObjects.Add(name, obj);
                    }
                }                
            }
        }
    }
}
