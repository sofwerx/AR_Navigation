﻿using System;
using UnityEngine;
using Utils.NativeHelpers.Android;
using Newtonsoft.Json.Linq;
using Managers;
using Utils.File;

namespace Assets.Scripts.Managers
{
    class NativeManager : Singleton<NativeManager>
    {
        [SerializeField]
        private bool m_IsDemoMode = false;

        private bool isInitialized = false;

        void Start()
        {
#if UNITY_EDITOR
            m_IsDemoMode = true;
#endif
            if (!m_IsDemoMode)
            {
                initialize();
            }
        }

        public void loadData()
        {
            if (m_IsDemoMode)
            {
                string features = "[{\"FeatureName\":\"poi_test3\",\"FeatureInfo\":[{\"geom\":{\"MULTIPOINT\":[{\"x\":-81.22361537791122,\"y\":28.601170554801193}]},\"id\":1,\"fid\":1},{\"geom\":{\"MULTIPOINT\":[{\"x\":-81.22314864532017,\"y\":28.601220574722557}]},\"id\":2,\"fid\":2},{\"geom\":{\"MULTIPOINT\":[{\"x\":-81.22317494011405,\"y\":28.600327907931362}]},\"id\":3,\"fid\":3},{\"geom\":{\"MULTIPOINT\":[{\"x\":-81.22369207105999,\"y\":28.600381775969968}]},\"id\":4,\"fid\":4}]},{\"FeatureName\":\"cnp_test3\",\"FeatureInfo\":[{\"geom\":{\"MULTIPOINT\":[{\"x\":-81.22208986573676,\"y\":28.601279570418495}]},\"id\":\"1\",\"fid\":1},{\"geom\":{\"MULTIPOINT\":[{\"x\":-81.22163847177545,\"y\":28.601264179683874}]},\"id\":\"2\",\"fid\":2},{\"geom\":{\"MULTIPOINT\":[{\"x\":-81.22166476656932,\"y\":28.600510030926007}]},\"id\":\"3\",\"fid\":3},{\"geom\":{\"MULTIPOINT\":[{\"x\":-81.22209863066804,\"y\":28.60051772634882}]},\"id\":\"4\",\"fid\":4}]},{\"FeatureName\":\"route_test3\",\"FeatureInfo\":[{\"geom\":{\"MULTILINESTRING\":[[{\"x\":-81.22263578519043,\"y\":28.601245416397788},{\"x\":-81.22238093593946,\"y\":28.600633829502986},{\"x\":-81.22207511683828,\"y\":28.600223616786504},{\"x\":-81.22170133793686,\"y\":28.59991036236107},{\"x\":-81.22149745853608,\"y\":28.599753734798195},{\"x\":-81.22140401381074,\"y\":28.599410645035213},{\"x\":-81.22144648868588,\"y\":28.599112305200407},{\"x\":-81.22128508416029,\"y\":28.598537998634},{\"x\":-81.2218202675873,\"y\":28.598597666994785},{\"x\":-81.221998662063,\"y\":28.5988512571502},{\"x\":-81.22239792588952,\"y\":28.59917943173708},{\"x\":-81.22275471484089,\"y\":28.599470312900532},{\"x\":-81.22301805906689,\"y\":28.59973881787527},{\"x\":-81.22328989826792,\"y\":28.600156490916802},{\"x\":-81.22345979776857,\"y\":28.60042499413832},{\"x\":-81.22340882791839,\"y\":28.60066366309263}]]},\"id\":1,\"fid\":1}]},{\"FeatureName\":\"aoi_test3\",\"FeatureInfo\":[{\"geom\":{\"MULTIPOLYGON\":[[[{\"x\":-81.22310301570197,\"y\":28.599798503989135},{\"x\":-81.22265403966122,\"y\":28.600249010538903},{\"x\":-81.2217935022498,\"y\":28.599624870740804},{\"x\":-81.222263858102,\"y\":28.599127433360024},{\"x\":-81.22310301570197,\"y\":28.599798503989135}]]]},\"id\":1,\"fid\":1}]}]";
                JArray geoPackageData = JArray.Parse(features);
                RealWorldObjectManager.Instance.geopackageParser(geoPackageData);
            }
            else
            {
                string directoryPath = TalosFileFinder.GetDirectoryPath("GeoPackage");
                AndroidJavaObject instance = AndroidHelper.getNativeInterface();
                object[] values = new object[1];
                values[0] = directoryPath;

                if (instance.Call<bool>("openGeoPackageFile", values))
                {
                    string features = instance.Call<string>("parseGeoPackageFile", values);
                    JArray geoPackageData = JArray.Parse(features);
                    RealWorldObjectManager.Instance.geopackageParser(geoPackageData);
                    Debug.Log(features);
                }
            }
        }
        public void initialize()
        {
#if UNITY_ANDROID
            AndroidJavaObject activityContext = null;
            using (AndroidJavaClass activityClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
            {
                activityContext = activityClass.GetStatic<AndroidJavaObject>("currentActivity");
            }
            AndroidJavaObject instance = AndroidHelper.getNativeInterface();
            instance.Call("setApplicationActivity", activityContext);
#endif
        }
    }
}
