using Assets.Scripts.Managers;
using Mapbox.Unity.Ar;
using Mapbox.Unity.Location;
using Mapbox.Unity.Map;
using Mapbox.Unity.Utilities;
using Mapbox.Utils;
using System.Collections.Generic;
using UnityEngine;
using HUDElements;
using Mapbox.Map;
using Mapbox.Unity.MeshGeneration.Data;
using UnityARInterface;
using System.Collections;

namespace Managers
{
    public class MapboxLocationManager : LocationManager
    {
        [SerializeField]
        public AbstractMap m_Map;

        [SerializeField]
        private LocationProviderFactory m_LocationProvider;

        [SerializeField]
        private ManualSynchronizationContextBehaviour m_SynchronizationContextBehavior;

        [SerializeField]
        private AverageHeadingAlignmentStrategy m_AverageHeadingAlignmentStrategy;

        [SerializeField]
        private RangeAroundTransformTileProvider m_TileProvider;

        [SerializeField]
        float _scaleTime = 5f;

        [SerializeField]
        float _fadeTime = 1f;

        [SerializeField]
        AnimationCurve _scaleUpCurve;

        [SerializeField]
        AnimationCurve _scaleDownCurve;

        [SerializeField]
        GameObject m_AR_Root;

        [SerializeField]
        Camera m_AR_Camera;

        [SerializeField]
        GameObject m_MapCamera;

        [SerializeField]
        Transform _player;

        private Alignment m_CurrentAlignment;

        bool _hasAnchor;
        bool m_Transitioning = false;
        bool isInit = false;

        private Location m_PreviousLocation;

        ArrayList m_BoundedPlanes = new ArrayList();

        public Transform MapAnchor;

        private bool m_InitialAlignmentSet = false;

        public override float CompassHeading
        {
            get
            {
                return Input.compass.trueHeading;
            }
        }

        public override Vector3 CurrentOffset
        {
            get { return m_CurrentAlignment.Position; }
        }

        public override float CurrentRotationOffset
        {
            get {return m_CurrentAlignment.Rotation; }
        }

        public override Vector3 CurrentUserLocation()
        {
#if UNITY_EDITOR
            return VectorExtensions.ToVector3xz(m_LocationProvider.EditorLocationProvider.CurrentLocation.LatitudeLongitude);
#else
            return VectorExtensions.ToVector3xz(m_LocationProvider.DeviceLocationProvider.CurrentLocation.LatitudeLongitude);
#endif
        }

        public override Vector3 LatLonToUnityMeters(double lat, double lon)
        {
            Vector2d location;
#if UNITY_EDITOR
            location = m_LocationProvider.EditorLocationProvider.CurrentLocation.LatitudeLongitude;
#else
            location = m_LocationProvider.DeviceLocationProvider.CurrentLocation.LatitudeLongitude;
#endif


            return Conversions.GeoToWorldPosition(
                    lat, lon,
                    m_Map.CenterMercator,
                    m_RealWorldScale).ToVector3xz();
        }

        private void RecenterMap(Location location)
        {
            float distance = Vector3.Distance(LatLonToUnityMeters(m_PreviousLocation.LatitudeLongitude.x, m_PreviousLocation.LatitudeLongitude.y),
                                              LatLonToUnityMeters(location.LatitudeLongitude.x, location.LatitudeLongitude.y));
            if (distance > 25)
            {
                //How far have we traveled...
                Debug.Log("Distance traveled: " + distance);
                m_Map.Reset();
                m_Map.Initialize(location.LatitudeLongitude, (int)m_Map.Zoom);
                RealWorldObjectManager.Instance.reloadPoints();
            }
            m_PreviousLocation = location;
        }

        private void PlaneAddedHandler(BoundedPlane plane)
        {
            m_BoundedPlanes.Add(plane);
        }

        protected override void Initialize()
        {            
            ARInterface.planeAdded += PlaneAddedHandler;
#if UNITY_EDITOR
            m_LocationProvider.EditorLocationProvider.OnLocationUpdated += MapInitialized;
            m_LocationProvider.EditorLocationProvider.OnLocationUpdated += RecenterMap;
#else
            m_LocationProvider.DeviceLocationProvider.OnLocationUpdated += MapInitialized;
            m_LocationProvider.DeviceLocationProvider.OnLocationUpdated += RecenterMap;
#endif
            m_SynchronizationContextBehavior.OnAlignmentAvailable += OnAlignmentAvailable;
            m_Map.OnInitialized += () => isInit = true;

            m_CurrentMode = MapMode.WorldScale;

        }

        private void MapInitialized(Location location)
        {
#if UNITY_EDITOR
            m_LocationProvider.EditorLocationProvider.OnLocationUpdated -= MapInitialized;
#else
            m_LocationProvider.DeviceLocationProvider.OnLocationUpdated -= MapInitialized;
#endif

            //m_TableTopScale = 0.003273406f;
            m_TableTopScale = 100;
            m_RealWorldScale = 1;
            m_Map.Initialize(location.LatitudeLongitude, (int)m_Map.Zoom);
        }

        public override Vector3 CurrentUserLocationInUnityMeters()
        {
            Vector2d userLocation;
#if UNITY_EDITOR
            userLocation = m_LocationProvider.EditorLocationProvider.CurrentLocation.LatitudeLongitude;
#else
            userLocation = m_LocationProvider.DeviceLocationProvider.CurrentLocation.LatitudeLongitude;
#endif

            return LatLonToUnityMeters(userLocation.x, userLocation.y);
        }

        public void OnAlignmentAvailable(Alignment alignment)
        {
            Debug.Log("Booyaka");
            m_CurrentAlignment = alignment;
            RealWorldObjectManager.Instance.updateAlignment(alignment.Position, alignment.Rotation);            
        }

        public override void OnAlignmentAvailable(Vector3 point, float rotation)
        {
            RealWorldObjectManager.Instance.updateAlignment(point, rotation);
        }

        public override void AddARItemToMap(BaseARItem item)
        {
            item.transform.SetParent(m_Map.transform);
        }

        public override double GetHeightAtPoint(double lat, double lon)
        {
            var tileIDUnwrapped = TileCover.CoordinateToTileId(new Mapbox.Utils.Vector2d(lat, lon), (int)m_Map.Zoom);

            //get tile
            UnityTile tile = m_Map._mapVisualizer.GetUnityTileFromUnwrappedTileId(tileIDUnwrapped);

            //lat lon to meters because the tiles rect is also in meters
            Vector2d v2d = Conversions.LatLonToMeters(new Mapbox.Utils.Vector2d(lat, lon));
            //get the origin of the tile in meters
            Vector2d v2dcenter = tile.Rect.Center - new Mapbox.Utils.Vector2d(tile.Rect.Size.x / 2, tile.Rect.Size.y / 2);
            //offset between the tile origin and the lat lon point
            Vector2d diff = v2d - v2dcenter;

            //maping the diffetences to (0-1)
            float Dx = (float)(diff.x / tile.Rect.Size.x);
            float Dy = (float)(diff.y / tile.Rect.Size.y);

            //height in unity units
            double h = tile.QueryHeightData(Dx, Dy);
            return h;
        }

        public override double GetPlayerHeight()
        {
            Vector2d location;
#if UNITY_EDITOR
            location = m_LocationProvider.EditorLocationProvider.CurrentLocation.LatitudeLongitude;
#else
            location = m_LocationProvider.DeviceLocationProvider.CurrentLocation.LatitudeLongitude;
#endif

            return GetHeightAtPoint(location.x, location.y);
        }

        public override float GetWorldScale()
        {
            return m_RealWorldScale;
        }

        public override float GetTableScale()
        {
            return m_TableTopScale;
        }

        public override void SplatMap()
        {
            Debug.Log("Tabletop: " + m_TableTopScale);
            m_Map.SetWorldRelativeScale(m_TableTopScale);
            _player.position = Vector3.zero;
            _player.rotation = Quaternion.identity;
        }

        public override void SwitchMode()
        {
            if(!m_Transitioning)
            {
                if (!m_TableTopMode)
                {
                    m_CurrentMode = MapMode.TableScale;
                    m_Transitioning = true;
                    m_MapCamera.SetActive(true);
                    StartCoroutine(ZoomOut());
                    m_TableTopMode = true;
                }
                else
                {
                    m_CurrentMode = MapMode.WorldScale;
                    m_Transitioning = true;
                    StartCoroutine(ZoomIn());
                    m_TableTopMode = false;
                }

                //if (!m_TableTopMode)
                //{
                //    m_Map.transform.SetParent(MapAnchor);
                //    SplatMap();
                //    StartCoroutine(ScaleDownRoutine());
                //    m_TableTopMode = true;
                //}
                //else
                //{
                //    StartCoroutine(ScaleUpRoutine());
                //    m_TableTopMode = false;
                //}
            }

        }

        IEnumerator ZoomIn()
        {
            float elapsedTime = 0;
            while (elapsedTime < _scaleTime)
            {
                elapsedTime += Time.deltaTime;
                var t = elapsedTime / _scaleTime;

                var curveValue = _scaleUpCurve.Evaluate(t);
                var scale = Mathf.Lerp(m_MapCamera.transform.position.y, 0, curveValue);
                float rotationScale = Mathf.Lerp(m_MapCamera.transform.rotation.eulerAngles.x, 0, curveValue);
                if (scale != 0)
                {
                    m_MapCamera.transform.position = new Vector3(m_AR_Camera.transform.position.x, scale, m_AR_Camera.transform.position.z);
                    m_MapCamera.transform.rotation = Quaternion.Euler(rotationScale, 0, 0);
                }
                yield return null;
            }
            m_AR_Camera.enabled = true;
            m_MapCamera.SetActive(false);
            m_Transitioning = false;
            RealWorldObjectManager.Instance.switchMode(MapMode.WorldScale);
        }

        IEnumerator ZoomOut()
        {
            float elapsedTime = 0;
            Transform cameraTransform = m_AR_Camera.transform;
            while (elapsedTime < _scaleTime)
            {
                elapsedTime += Time.deltaTime;
                var t = elapsedTime / _scaleTime;

                var curveValue = _scaleUpCurve.Evaluate(t);
                var scale = Mathf.Lerp(cameraTransform.position.y, 250, curveValue);
                float rotationScale = Mathf.Lerp(cameraTransform.rotation.eulerAngles.y, 90, curveValue);
                
                if (scale != 0)
                {
                    m_MapCamera.transform.position = new Vector3(m_AR_Camera.transform.position.x, scale, m_AR_Camera.transform.position.z);
                    m_MapCamera.transform.rotation = Quaternion.Euler(rotationScale, 0, 0);
                }
                yield return null;
            }
            m_AR_Camera.enabled = false;
            m_Transitioning = false;
            RealWorldObjectManager.Instance.switchMode(MapMode.TableScale);
        }

        IEnumerator ScaleUpRoutine()
        {
            var tiles = Resources.FindObjectsOfTypeAll<UnityTile>();
            var elapsedTime = 0f;

            Debug.Log("World Relative Scale: " + m_RealWorldScale);

            var alphaId = Shader.PropertyToID("_Alpha");
            while (elapsedTime < _scaleTime)
            {
                elapsedTime += Time.deltaTime;
                var t = elapsedTime / _scaleTime;

                var curveValue = _scaleUpCurve.Evaluate(t);
                var scale = Mathf.Lerp(m_TableTopScale, m_RealWorldScale, curveValue);
                if (scale != 0)
                {
                    m_Map.SetWorldRelativeScale(scale);
                    MapAnchor.localScale = Vector3.one * scale;
                }
                yield return null;
            }

            elapsedTime = 0f;
            while (elapsedTime < _fadeTime)
            {
                elapsedTime += Time.deltaTime;
                var t = elapsedTime / _fadeTime;
                var alpha = 1 - _scaleUpCurve.Evaluate(t);

                foreach (var tile in tiles)
                {
                    tile.MeshRenderer.material.SetFloat(alphaId, alpha);
                }

                yield return null;
            }
            MapAnchor.transform.localPosition = new Vector3(0, 0f, 0);
            RealWorldObjectManager.Instance.switchMode(MapMode.WorldScale);
        }

        IEnumerator ScaleDownRoutine()
        {
            var tiles = Resources.FindObjectsOfTypeAll<UnityTile>();
            foreach (var tile in tiles)
            {
                tile.gameObject.SetActive(true);
            }

            MapAnchor.localPosition = UIController.Instance.m_firstPersonCamera.transform.position + new Vector3(0, -1f, 3f);

            var alphaId = Shader.PropertyToID("_Alpha");

            float elapsedTime = 0f;
            while (elapsedTime < _fadeTime / 2)
            {
                elapsedTime += Time.deltaTime;
                var t = elapsedTime / (_fadeTime / 2);
                var alpha = 1 - _scaleDownCurve.Evaluate(t);
                foreach (var tile in tiles)
                {
                    tile.MeshRenderer.material.SetFloat(alphaId, alpha);
                }

                yield return null;
            }

            elapsedTime = 0f;

            while (elapsedTime < _scaleTime / 2)
            {
                elapsedTime += Time.deltaTime;
                var t = elapsedTime / (_scaleTime / 2);

                var curveValue = _scaleDownCurve.Evaluate(t);
                var scale = Mathf.Lerp(m_TableTopScale, m_RealWorldScale, curveValue);
                if (scale != 0)
                {
                    m_Map.SetWorldRelativeScale(scale);
                    MapAnchor.localScale = Vector3.one * scale;
                    var alpha = 1 - _scaleDownCurve.Evaluate(t);
                }
                yield return null;
            }

            MapAnchor.localScale = (m_TableTopScale * 1) * Vector3.one;
            RealWorldObjectManager.Instance.switchMode(MapMode.TableScale);
        }

    }
}