﻿using Managers;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NavigationModeUI : MonoBehaviour
{
    [SerializeField]
    private Text m_LocationText;

    [SerializeField]
    private Text m_CompassText;

    [SerializeField]
    private LocationManager m_LocationManager;

    private float m_previousHeading;

    private string[] caridnals = { "N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW", "N" };


    // Use this for initialization
    void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        // Update Location text
        if (m_LocationText != null)
        {
            Vector3 location = m_LocationManager.CurrentUserLocation();
            m_LocationText.text = location.x + ", " + location.z;
        }

        if (m_CompassText != null)
        {
            float heading = LocationManager.Instance.CompassHeading;
            float deltaHeading = Math.Abs(heading - m_previousHeading);
            if (deltaHeading > 10)
            {
                int directionIndex = (int)Math.Round(((double)heading * 10 % 3600) / 225);
                int directionIndexLeft = directionIndex - 1;
                if (directionIndexLeft == -1)
                {
                    directionIndexLeft = caridnals.Length - 1;
                }

                int directionIndexRight = directionIndex + 1;
                if (directionIndexRight >= caridnals.Length)
                {
                    directionIndexRight = 0;
                }

                string headingText = caridnals[directionIndex];
                string compassText = caridnals[directionIndexLeft] + "      " + headingText + "      " + caridnals[directionIndexRight];
                m_CompassText.text = compassText;

            }
            m_previousHeading = heading;
        }
    }
}

