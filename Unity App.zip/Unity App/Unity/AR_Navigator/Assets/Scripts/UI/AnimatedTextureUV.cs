﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


class AnimatedTextureUV : MonoBehaviour
{
    int uvAnimationTileX = 6;
    int uvAnimationTileY = 5;

    float framesPerSecond = 30.0f;

    private void Start()
    {
        
    }

    void Update()
    {
        // Calculate index
        int index = (int)(Time.time * framesPerSecond);
        // repeat when exhausting all frames
        index = index % (uvAnimationTileX * uvAnimationTileY);

        // Size of every tile
        var size = new Vector2(1.0f / uvAnimationTileX, 1.0f / uvAnimationTileY);

        // split into horizontal and vertical index
        var uIndex = index % uvAnimationTileX;
        var vIndex = index / uvAnimationTileX;

        // build offset
        // v coordinate is the bottom of the image in opengl so we need to invert.
        var offset = new Vector2(uIndex * size.x, 1.0f - size.y - vIndex * size.y);

        //GetComponent<Renderer>().material.SetTextureOffset("_MainTex", offset);
        //GetComponent<Renderer>().material.SetTextureScale("_MainTex", size);

        GetComponent<LineRenderer>().material.SetTextureOffset("_MainTex", offset);
        GetComponent<LineRenderer>().material.SetTextureScale("_MainTex", size);
    }
}