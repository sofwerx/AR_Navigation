﻿namespace Mapbox.Unity.Utilities.DebugTools
{
	using UnityEngine;

	public class ScenesList : ScriptableObject
	{
        public SceneData[] SceneList;
	}
}