﻿using System;

namespace UnityEngine.XR.iOS
{
	public struct ARPoint
	{
		public double x;
		public double y;
	}
}

