package designinteractive.com.arnavigationplugin;

import android.content.Context;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mil.nga.geopackage.GeoPackage;
import mil.nga.geopackage.GeoPackageManager;
import mil.nga.geopackage.factory.GeoPackageFactory;
import mil.nga.geopackage.features.user.FeatureCursor;
import mil.nga.geopackage.features.user.FeatureDao;
import mil.nga.geopackage.features.user.FeatureRow;
import mil.nga.geopackage.features.user.FeatureTable;
import mil.nga.geopackage.geom.GeoPackageGeometryData;
import mil.nga.geopackage.tiles.overlay.FeatureRowData;
import mil.nga.wkb.geom.Geometry;

/**
 * Created by emartin on 3/6/2018.
 */

public class GeoPackageReader
{
    private GeoPackageManager mManager;
    private Context mApplicationContext;
    public String mfilePath;

    public GeoPackageReader()
    {

    }

    public void setApplicationContext(Context context)
    {
        System.out.println("Set application Context");
        mApplicationContext = context;
        mManager = GeoPackageFactory.getManager(mApplicationContext);
    }

    public void clearAllDatabases()
    {
        List<String> databases = mManager.databases();
        for(int i = 0; i < databases.size(); ++i)
        {
            mManager.delete(databases.get(i));
        }
    }

    public boolean openGeoPackageFile(String filePath, String databaseName)
    {
        boolean returnValue = false;

        File file = new File(filePath);
        if(mManager.importGeoPackage(databaseName, file))
        {
            returnValue = true;
        }

        return returnValue;
    }

    public boolean openGeoPackage(String databaseName, InputStream stream)
    {
        boolean returnValue = false;
        if(mManager.importGeoPackage(databaseName, stream))
        {
            returnValue = true;
        }

        return returnValue;
    }

    public JSONArray parseGeoPackageFile(String databaseName) throws JSONException
    {
        JSONArray featuresArray = new JSONArray();
        List<String> databases = mManager.databases();

        GeoPackage geoPackage = mManager.open(databaseName);
        List<String> features = geoPackage.getFeatureTables();
        List<String> tables = geoPackage.getTables();
//        Cursor abc = geoPackage.rawQuery("SELECT * from PHOTOS", null);
//        JSONArray photos = new JSONArray();
//        int k = 0;
//        while(abc.moveToNext())
//        {
//            byte[] def = abc.getBlob(1);
////            String encoded = Base64.encodeToString(def, 0);
////            photos.put(encoded);
//
//            File photo = new File(mfilePath, "photo_" + k + ".jpg");
//            System.out.println(photo.getAbsolutePath());
//
//            try
//            {
//                photo.createNewFile();
//
//                FileOutputStream fos=new FileOutputStream(photo.getPath());
//
//                fos.write(def);
//                fos.close();
//            }
//            catch (java.io.IOException e)
//            {
//                e.printStackTrace();
//            }
//++k;
//            abc.moveToNext();
//
//
//        }
        //featuresArray.put(photos);

//        while(abc.moveToNext())
//        {
//            abc.g
//        }
        for (int i = 0; i < features.size(); ++i)
        {
            String featureName = features.get(i);

            FeatureDao featureDao = geoPackage.getFeatureDao(featureName);
            FeatureCursor featureCursor = featureDao.queryForAll();

            JSONObject featureObject = new JSONObject();
            featureObject.put("FeatureName", featureName);

            JSONArray featureInfos = new JSONArray();
            try
            {
                while (featureCursor.moveToNext())
                {
                    FeatureRow featureRow = featureCursor.getRow();
                    FeatureTable ft = featureRow.getTable();
                    GeoPackageGeometryData geometryData = featureRow.getGeometry();
                    Geometry geometry = geometryData.getGeometry();

                    Map<String, Object> featureValues = new HashMap<>();
                    for (int j = 0; j < featureRow.getValues().length; ++j)
                    {
                        featureValues.put(ft.getColumnName(j), featureRow.getValue(j));
                    }

                    FeatureRowData frd = new FeatureRowData(featureValues, "geom");
                    Gson gson = new Gson();
                    JSONObject featureInfo = new JSONObject((HashMap<String, Object>) frd.jsonCompatible());

                    for (Map.Entry<String, Object> entry : featureValues.entrySet())
                    {
                        String key = entry.getKey();
                        Object value = entry.getValue();
                        if (value.getClass() != GeoPackageGeometryData.class)
                        {
                            featureInfo.put(key, value);
                        }
                    }
                    featureInfos.put(featureInfo);
                }
            }
            finally
            {
                featureCursor.close();
            }
            featureObject.put("FeatureInfo", featureInfos);
            featuresArray.put(featureObject);
        }
        geoPackage.close();
        return featuresArray;
    }
}
