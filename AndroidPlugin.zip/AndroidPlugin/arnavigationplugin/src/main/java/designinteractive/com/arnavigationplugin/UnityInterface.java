package designinteractive.com.arnavigationplugin;

import android.app.Activity;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.File;


/**
 * Created by emartin on 11/21/2017.
 */

public class UnityInterface
{
    private static UnityInterface mInstance = null;

    private Activity mUnityActivity;

    private GeoPackageReader mGeoPackageReader;

    private UnityInterface()
    {
        mGeoPackageReader = new GeoPackageReader();
    }

    public static synchronized UnityInterface getInstance()
    {
        if (mInstance == null)
        {
            mInstance = new UnityInterface();
        }
        return mInstance;
    }

    public synchronized void setApplicationActivity(Activity unityActivity)
    {
        System.out.println("setting application activity");
        mUnityActivity = unityActivity;
        mGeoPackageReader.setApplicationContext(mUnityActivity.getApplicationContext());
    }

    public synchronized boolean openGeoPackageFile(String filePath)
    {
        boolean returnValue = false;
        mGeoPackageReader.mfilePath = filePath;
        mGeoPackageReader.clearAllDatabases();
        File directory = new File(filePath);
        File[] fileList = directory.listFiles();
        for(int i = 0; i < fileList.length; ++i)
        {
            if(fileList[i].getName().contains(".gpkg"))
            {
                if (mGeoPackageReader.openGeoPackageFile(fileList[i].getAbsolutePath(), fileList[i].getName()))
                {
                }
            }
        }
        returnValue = true;
        return returnValue;
    }

    public synchronized String parseGeoPackageFile(String filePath)
    {
        JSONArray features = new JSONArray();
        try
        {
            File directory = new File(filePath);
            File[] fileList = directory.listFiles();
            for(int i = 0; i < fileList.length; ++i)
            {
                if(fileList[i].getName().contains(".gpkg"))
                {
                    JSONArray featureList = mGeoPackageReader.parseGeoPackageFile(fileList[i].getName());
                    for (int j = 0;
                         j < featureList.length();
                         ++j)
                    {
                        features.put(featureList.getJSONObject(j));
                    }
                }
            }
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return features.toString();
    }

    public synchronized void initialize()
    {

    }
}
